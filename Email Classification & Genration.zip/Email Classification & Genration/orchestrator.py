# orchestrator.py
from agents.email_classifier import EmailClassifier
from agents.response_generator import ResponseGenerator # UPDATED: Import ResponseGenerator
from agents.escalation_agent import EscalationAgent
import os

class Orchestrator:
    def __init__(self):
        try:
            # Initialize agents
            self.classifier = EmailClassifier()
            self.response_generator = ResponseGenerator() # UPDATED: Initialize ResponseGenerator
            self.escalation_agent = EscalationAgent()
            print("Orchestrator: All agents initialized successfully.")
        except Exception as e:
            print(f"Error initializing Orchestrator agents: {e}")
            raise # Re-raise to stop execution if agents can't be loaded

    def process_email(self, email_subject: str, email_body: str, action_type: str) -> dict:
        """
        Main workflow to process an incoming email based on requested action.
        action_type: 'classify', 'generate_response', 'escalate'
        """
        # Always classify first, as other actions depend on it
        classification_result = self.classifier.classify(email_subject, email_body)
        predicted_category = classification_result["predicted_category"]
        confidence = classification_result["confidence"]

        result = {
            "email_text": f"Subject: {email_subject}\n\nBody: {email_body}",
            "predicted_category": predicted_category,
            "confidence": confidence,
            "response_suggestion": None,
            "escalation_needed": False,
            "escalation_to": None,
            "escalation_reason": None
        }

        if action_type == 'generate_response':
            # Generate response only if requested
            response_suggestion = self.response_generator.generate_response(
                predicted_category, email_subject, email_body
            )
            result["response_suggestion"] = response_suggestion
        elif action_type == 'escalate':
            # Check for escalation only if requested
            escalation_result = self.escalation_agent.check_escalation(
                predicted_category, confidence, email_body
            )
            result["escalation_needed"] = escalation_result["escalation_needed"]
            result["escalation_to"] = escalation_result["escalation_to"]
            result["escalation_reason"] = escalation_result["reason"]

        # For 'classify' action, only classification_result is needed, which is always done.
        return result