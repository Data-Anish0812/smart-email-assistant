# agents/response_generator.py
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch

class ResponseGenerator:
    def __init__(self):
        # ✅ Use lightweight model that works everywhere
        self.token = "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"
        self.model_id = "distilgpt2"
        self.max_new_tokens = 200

        try:
            print("Loading tokenizer and model...")

            self.tokenizer = AutoTokenizer.from_pretrained(self.model_id, token=self.token)
            self.model = AutoModelForCausalLM.from_pretrained(self.model_id, token=self.token)

            print("Model loaded successfully.")
        except Exception as e:
            raise RuntimeError(f"Model loading failed: {e}")

    def _generate_text_from_mistral(self, prompt: str) -> str:
        try:
            inputs = self.tokenizer(prompt, return_tensors="pt")
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=self.max_new_tokens,
                temperature=0.7,
                top_p=0.9,
                do_sample=True
            )
            decoded = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            return decoded.replace(prompt, "").strip()
        except Exception as e:
            return f"Failed to generate response: {e}"

    def generate_response(self, category: str, email_subject: str, email_body: str) -> str:
        prompt = f"""You are an AI assistant for a corporate email system.
Based on the email details and category, generate a polite and professional reply.

Email Category: {category}
Email Subject: {email_subject}
Email Body: {email_body}

Draft Response:"""
        return self._generate_text_from_mistral(prompt)
