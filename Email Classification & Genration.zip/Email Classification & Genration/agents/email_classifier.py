import pickle
import re
import string
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import numpy as np
import os
import nltk

try:
    _ = nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')
try:
    _ = nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')
try:
    _ = nltk.data.find('corpora/omw-1.4')
except LookupError:
    nltk.download('omw-1.4')

class EmailClassifier:
    def __init__(self, model_path='models/classifier_model.pkl',
                 vectorizer_path='models/tfidf_vectorizer.pkl',
                 label_encoder_path='models/label_encoder.pkl'):
        try:
            self.model_path = model_path
            self.vectorizer_path = vectorizer_path
            self.label_encoder_path = label_encoder_path

            print(f"Loading model from: {self.model_path}")
            with open(self.model_path, 'rb') as f:
                self.model = pickle.load(f)

            print(f"Loading vectorizer from: {self.vectorizer_path}")
            with open(self.vectorizer_path, 'rb') as f:
                self.tfidf_vectorizer = pickle.load(f)

            print(f"Loading encoder from: {self.label_encoder_path}")
            with open(self.label_encoder_path, 'rb') as f:
                self.label_encoder = pickle.load(f)

            self.stopwords = set(stopwords.words('english'))
            self.lemmatizer = WordNetLemmatizer()

            print("All components loaded successfully!")
            if hasattr(self.label_encoder, 'classes_'):
                print(f"Loaded LabelEncoder classes: {self.label_encoder.classes_}")
            else:
                print("WARNING: Loaded LabelEncoder does not have 'classes_' attribute.")

        except FileNotFoundError as e:
            raise FileNotFoundError(
                f"Missing required files in the model directory:\n"
                f"Expected: {[self.model_path, self.vectorizer_path, self.label_encoder_path]}\n"
            )
        except Exception as e:
            raise Exception(f"Loading failed: {str(e)}")

    def _clean_text(self, text):
        text = text.lower()
        text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
        text = re.sub(r'@\w+', '', text)
        text = re.sub(r'#\w+', '', text)
        text = text.translate(str.maketrans('', '', string.punctuation))
        text = re.sub(r'\d+', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def _remove_stopwords(self, text):
        tokens = text.split()
        filtered_tokens = [word for word in tokens if word not in self.stopwords]
        return ' '.join(filtered_tokens)

    def _lemmatize_text(self, text):
        tokens = text.split()
        lemmatized_tokens = [self.lemmatizer.lemmatize(word) for word in tokens]
        return ' '.join(lemmatized_tokens)

    def preprocess_email_text(self, email_text):
        cleaned = self._clean_text(email_text)
        without_stopwords = self._remove_stopwords(cleaned)
        lemmatized = self._lemmatize_text(without_stopwords)
        return lemmatized

    def classify(self, email_subject: str, email_body: str) -> dict:
        """
        Classifies an email and returns the predicted category and confidence.
        """
        full_email_text = f"{email_subject} {email_body}"
        if not full_email_text.strip():
            return {"predicted_category": "Unknown", "confidence": 0.0, "reason": "Empty email content"}

        preprocessed_input = self.preprocess_email_text(full_email_text)

        if not preprocessed_input.strip():
            return {"predicted_category": "Unknown", "confidence": 0.0, "reason": "Content too short or removed during preprocessing"}

        try:
            # transform expects an iterable, even for a single document
            input_vector = self.tfidf_vectorizer.transform([preprocessed_input])
            probabilities = self.model.predict_proba(input_vector)[0]
            predicted_class_index = np.argmax(probabilities)
            confidence = probabilities[predicted_class_index]
            predicted_category = self.label_encoder.inverse_transform([predicted_class_index])[0]

        except Exception as e:
            print(f"DEBUG: An error occurred during classification: {e}")
          
            return {"predicted_category": "CLASSIFICATION_ERROR", "confidence": 0.0, "reason": f"Classification failed: {e}"}

        return {
            "predicted_category": predicted_category,
            "confidence": float(confidence)
        }