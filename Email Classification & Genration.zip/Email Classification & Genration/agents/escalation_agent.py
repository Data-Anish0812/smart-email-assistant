class EscalationAgent:
    def check_escalation(self, category: str, confidence: float, email_body: str) -> dict:
        """Determines if an email needs escalation."""
        escalation_needed = False
        escalation_to = None
        reason = None

        if category == "IT" and "urgent" in email_body.lower() and confidence < 0.8:
            escalation_needed = True
            escalation_to = "IT_Manager"
            reason = "Urgent IT request with lower confidence."
        elif category == "HR" and ("complaint" in email_body.lower() or "grievance" in email_body.lower()):
            escalation_needed = True
            escalation_to = "HR_Director"
            reason = "Sensitive HR matter."
        elif confidence < 0.6: # Low confidence for any category
            escalation_needed = True
            escalation_to = "Human_Review"
            reason = "Low classification confidence."

        return {
            "escalation_needed": escalation_needed,
            "escalation_to": escalation_to,
            "reason": reason
        }