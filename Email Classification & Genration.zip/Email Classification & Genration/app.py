import streamlit as st
from orchestrator import Orchestrator
import os

# --- Page Configuration ---
st.set_page_config(
    page_title="AI Email Assistant",
    page_icon="📧",
    layout="centered", # Can be "wide" for more space
    initial_sidebar_state="collapsed"
)

# --- Custom CSS for Decoration (Optional, but makes it unique) ---
st.markdown("""
<style>
    .stApp {
        background-color: #f0f2f6; /* Light gray background */
    }
    .main .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        padding-left: 1rem;
        padding-right: 1rem;
    }
    .stButton>button {
        width: 100%;
        border-radius: 0.5rem;
        border: 1px solid #4CAF50; /* Green border */
        color: white;
        background-color: #4CAF50; /* Green background */
        padding: 0.75rem 1rem;
        font-size: 1.1rem;
        font-weight: bold;
        transition: all 0.2s ease-in-out;
        box-shadow: 2px 2px 5px rgba(0,0,0,0.2);
    }
    .stButton>button:hover {
        background-color: #45a049; /* Darker green on hover */
        border-color: #45a049;
        transform: translateY(-2px);
        box-shadow: 4px 4px 10px rgba(0,0,0,0.3);
    }
    .stButton>button:active {
        transform: translateY(0);
        box-shadow: 1px 1px 2px rgba(0,0,0,0.2);
    }
    /* Specific styling for different buttons for visual differentiation */
    .stButton>button:nth-of-type(1) { /* Confidence button */
        background-color: #007bff; /* Blue */
        border-color: #007bff;
    }
    .stButton>button:nth-of-type(1):hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }
    .stButton>button:nth-of-type(2) { /* Generate Response button */
        background-color: #ffc107; /* Amber/Yellow */
        border-color: #ffc107;
        color: #333; /* Darker text for contrast */
    }
    .stButton>button:nth-of-type(2):hover {
        background-color: #e0a800;
        border-color: #e0a800;
    }
    .stButton>button:nth-of-type(3) { /* Escalate button */
        background-color: #dc3545; /* Red */
        border-color: #dc3545;
    }
    .stButton>button:nth-of-type(3):hover {
        background-color: #c82333;
        border-color: #c82333;
    }

    .stTextArea, .stTextInput {
        border-radius: 0.5rem;
        border: 1px solid #ccc;
        box-shadow: inset 1px 1px 3px rgba(0,0,0,0.1);
    }
    .stMarkdown h1 {
        color: #333;
        text-align: center;
        margin-bottom: 1.5rem;
        font-size: 2.5rem;
    }
    .stMarkdown h2 {
        color: #555;
        border-bottom: 2px solid #ddd;
        padding-bottom: 0.5rem;
        margin-top: 1.5rem;
        margin-bottom: 1rem;
    }
    .stInfo, .stWarning, .stError {
        border-radius: 0.5rem;
        padding: 1rem;
        margin-top: 1rem;
        box-shadow: 2px 2px 5px rgba(0,0,0,0.1);
    }
    .stMetric > div > div:first-child { /* Label */
        font-size: 1.2rem;
        font-weight: bold;
        color: #666;
    }
    .stMetric > div > div:nth-child(2) { /* Value */
        font-size: 2.5rem;
        font-weight: bold;
        color: #333;
    }
</style>
""", unsafe_allow_html=True)


# --- Initialize Orchestrator (Cached for performance) ---
@st.cache_resource
def load_orchestrator():
    model_dir = 'models'
    required_files = ['classifier_model.pkl', 'tfidf_vectorizer.pkl', 'label_encoder.pkl']
    for f in required_files:
        full_path = os.path.join(model_dir, f)
        if not os.path.exists(full_path):
            st.error(f"Error: Missing model file '{f}'. Please ensure all model files are in the 'models/' directory.")
            st.stop() # Stop the app if essential files are missing

    try:
        return Orchestrator()
    except Exception as e:
        st.error(f"Failed to initialize Orchestrator. This often means required model files or NLTK data are missing/corrupted, or HF_TOKEN is not set. Error: {e}")
        st.stop()

orchestrator = load_orchestrator()

# --- Streamlit Session State for Results ---
if 'classification_result' not in st.session_state:
    st.session_state.classification_result = None
if 'generated_response' not in st.session_state:
    st.session_state.generated_response = None
if 'escalation_info' not in st.session_state:
    st.session_state.escalation_info = None
if 'last_email_subject' not in st.session_state:
    st.session_state.last_email_subject = ""
if 'last_email_body' not in st.session_state:
    st.session_state.last_email_body = ""


# --- UI Elements ---
st.title("AI Email Routing & Response Assistant 🤖")
st.markdown("---") # Separator

st.write("### Input Email Details")
subject_input = st.text_input("Email Subject", key="subject_input",
                               placeholder="e.g., Printer not working, Urgent request for leave")
body_input = st.text_area("Email Body", key="body_input", height=150,
                           placeholder="e.g., Team,\n\nAccess to the project folder is denied. My printer is also not working. Please fix it ASAP.")

st.write("---")

col1, col2, col3 = st.columns(3)

with col1:
    classify_button = st.button("🔎 Classify & Confidence", key="classify_btn")
with col2:
    generate_button = st.button("✍️ Generate Response", key="generate_btn")
with col3:
    escalate_button = st.button("🚨 Check for Escalation", key="escalate_btn")

# --- Logic for Button Clicks ---
if classify_button or generate_button or escalate_button:
    # Check if email content is provided
    if not subject_input.strip() and not body_input.strip():
        st.warning("Please enter some text in the subject or body to process the email.")
    else:
        # Update session state with current inputs
        st.session_state.last_email_subject = subject_input
        st.session_state.last_email_body = body_input

        with st.spinner("Processing your request..."):
            try:
                # Perform full classification first for all paths
                classification_info = orchestrator.process_email(
                    subject_input, body_input, action_type='classify'
                )
                st.session_state.classification_result = classification_info

                # Then perform specific actions based on button clicked
                if classify_button:
                    st.session_state.generated_response = None # Clear other results
                    st.session_state.escalation_info = None
                elif generate_button:
                    st.session_state.generated_response = orchestrator.process_email(
                        subject_input, body_input, action_type='generate_response'
                    )["response_suggestion"]
                    st.session_state.escalation_info = None
                elif escalate_button:
                    escalation_full_result = orchestrator.process_email(
                        subject_input, body_input, action_type='escalate'
                    )
                    st.session_state.escalation_info = {
                        "needed": escalation_full_result["escalation_needed"],
                        "to": escalation_full_result["escalation_to"],
                        "reason": escalation_full_result["escalation_reason"]
                    }
                    st.session_state.generated_response = None # Clear other results


            except Exception as e:
                st.error(f"An error occurred during email processing: {e}")
                st.info("Please check the terminal for more detailed error messages during Orchestrator initialization.")
                st.session_state.classification_result = None
                st.session_state.generated_response = None
                st.session_state.escalation_info = None


# --- Display Results based on Session State ---
st.write("---")
st.write("### Results")

if st.session_state.classification_result:
    result = st.session_state.classification_result
    st.write("#### Classification & Confidence:")
    st.metric(label="Category", value=result["predicted_category"],
              delta=f"{result['confidence']:.2f} Confidence")

if st.session_state.generated_response:
    st.write("#### Suggested Response:")
    st.info(st.session_state.generated_response)

if st.session_state.escalation_info:
    escalation = st.session_state.escalation_info
    st.write("#### Escalation Check:")
    if escalation["needed"]:
        st.error(f"🚨 Escalation Required to: **{escalation['to']}**")
        if escalation["reason"]:
            st.write(f"Reason: _{escalation['reason']}_")
    else:
        st.success("✅ No immediate escalation needed.")

# Optional: Add a clear button to reset inputs/results
if st.button("Clear Results & Input", key="clear_btn"):
    st.session_state.classification_result = None
    st.session_state.generated_response = None
    st.session_state.escalation_info = None
    st.session_state.last_email_subject = ""
    st.session_state.last_email_body = ""
    st.rerun() # Rerun the app to clear inputs